<?php
class DataBase extends mysqli{
    private static $inst = null;
    private $UserID = "root";
    private $Pwd = "";
    private $dBID = "kids";
    private $Server = "localhost";
    
    public static function getInstance(){
        if(!self::$inst instanceof self){
            self::$inst = new self;
        }
        return self::$inst;
    }
    
    public function __clone() {
        trigger_error('Cannot create another instance', E_USER_ERROR);
    }
    
    public function __wakeup() {
        trigger_error('Deserializing is not allowed.', E_USER_ERROR);
    }
    
    public function __construct() {
        parent::__construct($this->Server, $this->UserID, 
                $this->Pwd, $this->dBID);
        if(mysqli_connect_error()){
            exit('Connection error (' . 
                    mysqli_connect_errno() . ') '.
                    mysqli_connect_error());
        }
        //parent::set_charset('UTF-8');
    }
    
    //revisit
    function dateForSQL($date) {
        if ($date == "")
            return null;
        else {
            $dateParts = date_parse($date);
            return $dateParts['year'] * 10000 + $dateParts['month'] * 100 + $dateParts['day'];
        }
    }
    
    public function getClientID($sessionUser){
        $ID = $this->query(
                "SELECT uid FROM users WHERE "
                . "uname ='" . $sessionUser . "' OR "
                . "email ='" . $sessionUser . "'" );
        if ($ID->num_rows > 0){
            $trgtTuple = $ID->fetch_row();
            return $trgtTuple[0];
        } else
            //return "Not found"; 
            return null;
    }
    
            
    public function verifyClient($accNum, $PWD){
        require ("DB/PDODataBase.php");
        $result = $dbConPDO->query("SELECT 1 FROM users WHERE "
                . "(uname = ". $accNum ." OR email = ". $accNum .") AND password =" . $PWD);
        return $result->data_seek(0);
    }
}
