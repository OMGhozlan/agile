<?php
session_start();
if (array_key_exists("user", $_SESSION)) {
    $sessionUser = $_SESSION['user'];
    echo "Welcome, " . $_SESSION['user'];
} else {
    header('Location: index.php');
    exit;
}
?>
<?php
//require_once ("DB/DataBase.php");
//if ($_SERVER ['REQUEST_METHOD'] == "POST"){
//session_start();
//$_SESSION['user'] = $_POST['user'];
//header('Location: x.php');
//exit;
//}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            Agile WebSite
        </title>
        <style type="text/css">
            body{
                background-color: black;
            }
            p#footer-txt {
                text-align: center;
                color: #303032;
                font-family: arial;
                font-size: 12px;
                padding: 0 32px;
                background-color: Black;
                color: white;
                float: bottom;
                margin-top: 43%;
                opacity: .9;
            }

            ul{
                list-style-type: none;
                margin: 0;
                padding: 0;
                background-color: black;
                overflow: hidden;
                opacity: .9;
            }
            li a{
                text-decoration: none;
                padding: 10px;
                display: block;
                width: 60px;
                color: white;
                opacity: .7;
            }

            li a:hover{
                background-color: white;
                color: black;
            }

            ul li {
                float: left;
            }

            .dropdown{
                background: silver;
                width: 10px;
                height: 30px; 
                text-align: center;

            }

            .ddlcontent{
                display: none;
                padding: 10px;
            }
            .dropdown:hover .ddlcontent{
                display: block;
                background-color: white;

            }

            ul li:hover ul{
                display: block;
                opacity: .9;

            }

            ul ul{
                display: none;
                position: absolute;
                background-color: black;
                opacity: .7;

            }

            .img-circle {
                border-radius: 80%;
            }
            .sidenav {

                width: 0;
                z-index: 1;
                background-color: #111;
                overflow-x: hidden;
                transition: 0.5s;
                padding-top: 60px;
                float: right;
            }

            .sidenav a {
                padding: 8px 8px 8px 32px;
                text-decoration: none;
                font-size: 25px;
                color: #818181;
                display: block;
                transition: 0.3s;
                font-language-override: right;
            }
            .sidenav .items {
                position: relative;
                padding: 8px 8px 8px 32px;
                text-decoration: none;
                font-size: 25px;
                color: #818181;
                display: block;
                transition: 0.3s;
                font-language-override: right;
            }

            .sidenav a:hover, .offcanvas a:focus{
                color: #f1f1f1;
            }

            .sidenav .closebtn {
                position: relative;
                float: right;
                top: 0;
                right: 25px;
                font-size: 36px;
                margin-left: 50px;
            }

            @media screen and (max-height: 450px) {
                .sidenav {padding-top: 15px;}
                .sidenav a {font-size: 18px;}
            }
        </style>

    </head>
    <body>
        <ul>
            <li ><a href="@">Home</a></li>
            <li > <a href="@">Games</a>
                <ul>
                    <li > <a href="@"> English</a></li><br>
                    <li > <a href="@"> Math</a></li><br>
                </ul>
            </li>
            <li ><a href="@">Profile</a></li>
            <li ><a href="@">Help</a></li>
            <li  ><a href="@">About us</a></li>
        </ul>

        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a><br>
            <img class="items img-circle" src="ibra.jpg" width="50" height="50">
            <span class="items"><?php echo $sessionUser . "<br/>"; ?></span>
            <span class="items">Score</span>
            <a class="items" href="index.php">Log Out</a>
        </div>

        <span style="font-size:30px;cursor:pointer;float:right;color:white" onclick="openNav()">Quick Menu</span>

        <script>
            function openNav() {
                document.getElementById("mySidenav").style.width = "250px";
            }

            function closeNav() {
                document.getElementById("mySidenav").style.width = "0";
            }
        </script>



        <p id="footer-txt"> <b>© Copyright 2016 - <a href="@">Complec-City</a> - All Rights Reserved</b> <br>	
            <a href="@">Contact us</a>
            <a href="@"> </a>
            <a href="@"> Developers </a>
            <a href="@"> Privacy </a>
            <a href="@"> Terms </a>
            <a href="@"> Help </a>
        </p>   


    </body>
</html>