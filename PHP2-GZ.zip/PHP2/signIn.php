<?php
require_once ("DB/DataBase.php");
//require_once ("DB/PDODataBase.php");
$usrNmEmpty = false;
$pwdEmpty = false;
$signInOK = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if ($_POST['user'] == "") {
        $usrNmEmpty = true;
    }

    if ($_POST['usrpwd'] == "") {
        $pwdEmpty = true;
    }
}

if ($_SERVER ['REQUEST_METHOD'] == "POST") {
    $usrInfo = $_POST['user'];
    $usrpswd = $_POST['usrpwd'];
    require ("DB/PDODataBase.php");
    $secureLogin = $dbConPDO->prepare("SELECT 1 FROM users WHERE (uname = :usr OR email = :usr ) AND password = :pwd");
    $secureLogin->bindParam(':usr', $usrInfo);
    $secureLogin->bindParam(':pwd', $usrpswd);
    $secureLogin->execute();
    $res = $secureLogin->rowCount();
    if ($res > 0) {
        $signInOK = true;
        session_start();
        $_SESSION['user'] = $_POST['user'];
        header('Location: home.php');
        exit;
    } else {
        
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Complec City - Log In</title>
        <style type="text/css">
            .form {
                background-color: black;
                color: white;
                margin: 4%;
                padding: 20px;
                opacity: .9;

            }

            #div1 {
                background-color: black;
                color: white;
                opacity: .9;
                width: 300px;

            }
            div {
                background-color: black;
                color: white;

            }
            p {
                font-family: arial;
            }
            h {
                font-family: impact;
                padding: 10px;
                font-size: 40px;
            }
            p#footer-txt {
                text-align: center;
                color: #303032;
                font-family: arial;
                font-size: 12px;
                padding: 0 32px;
                background-color: Black;
                color: white;
                margin-top: 21%;
                opacity: .9;
            }
            .home{
                font-family: impact;
                padding: 10px;
                font-size: 40px;
                text-decoration: none;
                color: white;
            }

        </style>


    </head>
    <body>

        <div >
            <a class="home" href="index.php">Complec-City</a>
        </div>
        <form name="logon" action="signIn.php" method="POST" >
            <div class="form" id="div1">
                <p> Username </p>
                <input type="text" name="user">
                <p> Password </p>
                <input type="password" name="usrpwd"> <br>
                <br>
                <?php
                if ($_SERVER['REQUEST_METHOD'] == "POST") {
                    if (!$signInOK) {
                        echo "<script>alert('Invalid name and/or password')</script>";
                    }
                }
                ?>
                <input type="submit" value="Login"/>
                <?php
                if ($usrNmEmpty || $pwdEmpty) {
                    echo "<script>alert('Please enter your login credientials')</script>";
                }
                ?>
                <a class="home" href="signUp.php" style="float: right; font-size: 25px"> Sign Up </a>
            </div>
        </form>
        <p id="footer-txt"> <b>© Copyright 2016 - <a href="@">Complec-City</a> - All Rights Reserved</b> <br>
            <br>
            <a href="@">Contact us</a>
            <a href="@"> </a>
            <a href="@"> Developers </a>

            <a href="@"> Privacy </a>
            <a href="@"> Terms </a>
            <a href="@"> Help </a>

        </p>
    </body>
</html>