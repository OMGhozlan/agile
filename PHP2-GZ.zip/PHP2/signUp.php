<?php
require_once ("DB/DataBase.php");
$accNumUsed = false;
$usrNmEmpty = false;
$invalidPwd = false;
$pwdEmpty = false;
$pwdConfirmEmpty = false;


if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if ($_POST['Username'] == "") {
        $usrNmEmpty = true;
    }

    $accNum = DataBase::getInstance()->getClientID($_POST['Username']);
    if ($accNum) {
        $accNumUsed = true;
    }

    if ($_POST['Usrpwd'] == "") {
        $pwdEmpty = true;
    }
    if ($_POST['UsrpwdCnfrm'] == "") {
        $pwdConfirmEmpty = true;
    }
    if ($_POST['Usrpwd'] !== $_POST['UsrpwdCnfrm']) {
        $invalidPwd = true;
    }
    if (!$usrNmEmpty && !$accNumUsed &&
            !$pwdEmpty && !$pwdConfirmEmpty && !$invalidPwd) {
        require ("DB/PDODataBase.php");
        try {
            $Query = "INSERT INTO users SET uid=?, uname=?, password=?, email=?";
            $prepareQuery = $dbConPDO->prepare($Query);
            $accNumMD5 = MD5($_POST['Username'] . $_POST['Email']);
            $temp = array($accNumMD5, $_POST['Username'], $_POST['Usrpwd'], $_POST['Email']);
            if ($prepareQuery->execute($temp)) {
                echo"<script>alert('Record was saved.'); location.href='index.php'</script>";
            } else {
                echo $prepareQuery->execute($temp);
                echo "<font size =12>FAIL</font>";
            }
        } catch (PDOException $PDOe) {
            echo "Failure: " . $PDOe->getMessage();
        }
    }
}
?>
<!-------------------------------->
<!DOCTYPE html>
<html>
    <head>
        <title>Complec City - Sign Up</title>
        <style type="text/css">
            .form {
                background-color: black;
                color: white;
                margin: 4%;
                padding: 30px;
                opacity: .9;

            }

            div {
                background-color: black;
                color: white;
                opacity: .9;

            }
            p {
                font-family: arial;
            }
            h {
                font-family: impact;
                padding: 10px;
                font-size: 40px;
            }
            p#footer-txt {
                text-align: center;
                color: #303032;
                font-family: arial;
                font-size: 12px;
                padding: 0 32px;
                background-color: Black;
                color: white;

                opacity: .9;
            }
            .home{
                font-family: impact;
                padding: 10px;
                font-size: 40px;
                text-decoration: none;
                color: white;
            }
            a.home:hover{
                font-family: impact;
                padding: 10px;
                font-size: 40px;
                text-decoration: none;
                color: white;
            }

        </style>


    </head>
    <body>

        <div>
            <a class="home" href="index.php">Complec-City</a>
        </div>
        <form action ="signUp.php" method ="POST">
            <div class="form">
                <p> Username </p>
                <input type = "text" name ="Username"/> <br>
                <?php
                if ($usrNmEmpty) {
                    echo "<script>Name field(s) not filled, please fill it</script>";
                    echo ("Name field(s) not filled, please fill it.");
                    echo ("<br/>");
                }
                if ($accNumUsed) {
                    echo "<script>You cannot create multiple accounts</script>";
                    echo ("You cannot create multiple accounts");
                    echo ("<br/>");
                }
                ?>
                <p> Password </p>
                <input type="password" name="Usrpwd"> <br>
                <?php
                if ($pwdEmpty) {
                    echo "<script>alert('Enter the desired password')</script>";
                    echo ("Enter the desired password");
                    echo ("<br/>");
                }
                ?>
                <p> Confirm Password </p>
                <input type="password" name="UsrpwdCnfrm"> <br>
                <p> E-mail </p>
                <input type = "text" name ="Email"/><br>
                <p> Confirm E-mail </p>
                <input type = "text" name ="EmailCnfrm"> <br>
                <p> Gender </p>
                <select>
                    <option> Default </option>
                    <option> Male </option>
                    <option> Female </option>
                </select> <br> <br>
                <input type ="submit" name="SignUp" value ="Sign up" style="float: center;">
                <?php
                if ($pwdConfirmEmpty) {
                    echo "<script>alert('Please confirm your password')</script>";
                    echo ("Please confirm your password");
                    echo ("<br/>");
                }
                if (!$pwdConfirmEmpty && $invalidPwd) {
                    echo "<script>alert('The password are not matching')</script>";
                    echo("<div>The passwords are not matching</div>");
                    echo("<br/>");
                }
                ?>
                <!--a href="index.php"><font face = "Candara" size = "6" color = "blue">Back to main page</font></a-->
                </form>
            </div>

            <p id="footer-txt"> <b>© Copyright 2016 - <a href="@">Complec-City</a> - All Rights Reserved</b> <br>	
                Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.
                <br>
                <a href="@">Contact us</a>
                <a href="@"> </a>
                <a href="@"> Developers </a>

                <a href="@"> Privacy </a>
                <a href="@"> Terms </a>
                <a href="@"> Help </a>

            </p>
    </body>
</html>
<!--------------------------->